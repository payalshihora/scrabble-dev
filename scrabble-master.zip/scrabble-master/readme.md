Test Readme

PHP Version: 7.4

1. Fork code to your personal REPO
2. Make sure code is viable and works correctly
3. Work through any/all TODOS (check docblocs)
4. Build frontend to change tiles on demand and display results
5. Make any changes deemed beneficial
6. Create a PR in your forked personal REPO
7. Don't create a PR to this REPO
