<?php


namespace Src\Engine\Dictionary;


use Src\Boot;
use Throwable;

/**
 * Class Dictionary
 * @package Src\Engine\Dictionary
 */
class Dictionary extends AbstractDictionary implements DictionaryInterface
{

}
